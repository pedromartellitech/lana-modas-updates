# ====================== Lana Modas - App Completo (atualizado) ======================
from io import BytesIO
import os
import calendar
import tempfile
from datetime import datetime, date, timedelta
from streamlit_option_menu import option_menu
from datetime import datetime, date
import pandas as pd
import plotly.express as px
import streamlit as st
import streamlit.components.v1 as components
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
import time
from reportlab.platypus import Image, PageBreak

# ---------------- Caminhos & I/O seguro ----------------

APP_DIR = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
DATA_DIR = os.path.join(APP_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

def safe_read_csv(path: str, seps=(",", ";", "\t")) -> pd.DataFrame:
    if not os.path.exists(path):
        return pd.DataFrame()
    for s in seps:
        try:
            return pd.read_csv(path, sep=s, encoding="utf-8")
        except Exception:
            continue
    return pd.read_csv(path, encoding="utf-8")  # fallback

def safe_write_csv(df: pd.DataFrame, path: str, max_retries: int = 5, delay: float = 0.4):
    """Escrita atômica com retry (lida com arquivo aberto no Excel/OneDrive)."""
    df = df.copy()
    tmp_fd, tmp_path = tempfile.mkstemp(prefix="tmp_", suffix=".csv", dir=os.path.dirname(path))
    os.close(tmp_fd)
    df.to_csv(tmp_path, index=False, encoding="utf-8")
    last_err = None
    for _ in range(max_retries):
        try:
            os.replace(tmp_path, path)  # atômico em Windows/Linux
            return
        except PermissionError as e:
            last_err = e
            time.sleep(delay)  # espera e tenta de novo (Excel/OneDrive podem estar bloqueando)
    # se falhar todas
    try:
        os.remove(tmp_path)
    except Exception:
        pass
    raise last_err if last_err else RuntimeError("Falha ao gravar CSV.")

# ---------------- Config da página ----------------
st.set_page_config(page_title="Lana Modas", layout="wide")

# ---------------- Sidebar Moderno ----------------
with st.sidebar:
    escolha = option_menu(
        menu_title="👗 Lana Modas",  # título do menu
        options=[
            "🏠 Início",
            "📋 Cadastro de Vendas",
            "💸 Despesas",
            "📈 Relatórios"
        ],
        icons=["house", "cart-plus", "cash-stack", "bar-chart-line"],  # ícones Bootstrap
        menu_icon="shop",  # ícone do título
        default_index=0,  # item inicial
        styles={
            "container": {
                "padding": "5px",
                "background-color": "#090909",  # fundo escuro
                "border-radius": "12px"
            },
            "icon": {"color": "#FF006F", "font-size": "20px"},  # cor dos ícones
            "nav-link": {
                "font-size": "16px",
                "text-align": "left",
                "margin": "5px",
                "--hover-color": "#FF006F"
            },
            "nav-link-selected": {
                "background-color": "#FF006F",
                "color": "white",
                "font-weight": "bold"
            },
        }
    )

# ---------------- Arquivos ----------------
ARQ_REGISTROS = os.path.join(DATA_DIR, "registros.csv")
ARQ_DESPESAS  = os.path.join(DATA_DIR, "despesas.csv")

# chave para invalidar cache quando salvar algo
st.session_state.setdefault("reload_key", 0)

# ---------------- Loader com cache + chave ----------------
@st.cache_data
def carregar_df(path, colunas, reload_key: int = 0):
    try:
        df = pd.read_csv(path)
    except Exception:
        df = pd.DataFrame(columns=colunas)
    if "Data" in df.columns:
        df["Data"] = pd.to_datetime(df["Data"], errors="coerce")
    return df

def carregar_csv(caminho, colunas):
    """Carrega um CSV garantindo que as colunas existam"""
    if os.path.exists(caminho):
        df = pd.read_csv(caminho, encoding="utf-8", sep=",")
    else:
        df = pd.DataFrame(columns=colunas)

    for col in colunas:
        if col not in df.columns:
            df[col] = None

    return df

if escolha == "🏠 Início":
    # ---------- personalize aqui ----------
 DEV = {
    "nome": "Pedro Martelli",
    "headline": "Transformo ideias em sistemas úteis e práticos.",
    "sub": "Apps para varejo de moda • Dashboards financeiros • Automação de processos • Streamlit",
    "whatsapp": "",   # ex: "https://wa.me/55XXXXXXXXXXX"
    "instagram": "",  # ex: "https://instagram.com/seuusuario"
    "linkedin": "",   # ex: "https://www.linkedin.com/in/seulink"
    "github": "",     # ex: "https://github.com/seuusuario"
    "metric_clientes": 42,
    "metric_projetos": 65,
    "metric_satisfacao": 98,     # %
    "metric_resposta_horas": 2   # h
    }
 # --------------------------------------

 # CTAs só aparecem se houver link
 ctas = []
 if DEV.get("whatsapp"):  ctas.append(f"<a class='btn primary' href='{DEV['whatsapp']}' target='_blank' rel='noopener'>Fale no WhatsApp</a>")
 if DEV.get("instagram"): ctas.append(f"<a class='btn' href='{DEV['instagram']}' target='_blank' rel='noopener'>Instagram</a>")
 if DEV.get("linkedin"):  ctas.append(f"<a class='btn' href='{DEV['linkedin']}' target='_blank' rel='noopener'>LinkedIn</a>")
 if DEV.get("github"):    ctas.append(f"<a class='btn' href='{DEV['github']}' target='_blank' rel='noopener'>GitHub</a>")
 cta_html = "".join(ctas) or "<span class='muted'>Adicione seus links para mostrar os botões aqui.</span>"

 hora = datetime.now().hour
 saudacao = "Bom dia" if hora < 12 else ("Boa tarde" if hora < 18 else "Boa noite")

 html_inicio = f"""
 <html lang="pt-BR">
 <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <style>
    :root {{
      --bg: #0b0b0e; --panel: #14141a; --text: #fff; --muted: #b7b7c5;
      --brand: #FF006F; --brand2: #ff4d94; --stroke: rgba(255,255,255,0.10);
      --ok: #3ddc97; --warn: #ffcc00;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0; color: var(--text);
      font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      background:
        radial-gradient(1200px 600px at 10% -20%, #2a0f1f 0%, transparent 60%),
        radial-gradient(900px 500px at 110% 20%, #10152a 0%, transparent 60%),
        linear-gradient(180deg, #0b0b0e, #0e0e12);
    }}
    .wrap {{ padding: 28px 22px 42px; }}

    /* HERO */
    .hero {{
      position: relative; overflow: hidden;
      border: 1px solid var(--stroke); border-radius: 18px;
      padding: 28px 22px;
      background:
        linear-gradient(135deg, rgba(255,0,111,0.08), rgba(41,19,39,0.22)),
        linear-gradient(0deg, rgba(255,255,255,0.02), rgba(255,255,255,0.02));
      isolation: isolate;
    }}
    .hero::before {{
      content: ""; position: absolute; inset: -20%;
      background: conic-gradient(from 140deg, #ff4d94, #6a3df5, #18b2b8, #ff4d94);
      filter: blur(28px); opacity: .10; z-index: -1;
    }}
    .badge {{
      display:inline-block; font-size:12px; color:var(--muted);
      background: rgba(255,255,255,0.04); border:1px solid var(--stroke);
      padding:6px 10px; border-radius:999px; margin-bottom:10px;
    }}
    .titulo {{ font-size:36px; font-weight:900; margin:0 0 8px 0; letter-spacing:-0.6px; }}
    .highlight {{
      color: var(--brand);
      background: linear-gradient(90deg, rgba(255,0,111,.2), transparent);
      border-radius: 8px; padding: 0 6px;
    }}
    .sub {{ color: var(--muted); font-size:14px; margin:0; max-width: 900px; }}
    .cta {{ display:flex; gap:10px; flex-wrap:wrap; margin-top:12px; align-items:center; }}
    .btn {{
      padding:10px 14px; border-radius:12px; text-decoration:none; color:#fff;
      border:1px solid var(--stroke);
      background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02));
      transition: transform .15s ease, box-shadow .15s ease, border-color .15s ease;
      font-weight:700; outline: none;
    }}
    .btn.primary {{ background: linear-gradient(180deg, var(--brand), var(--brand2)); border-color: transparent; }}
    .btn:hover, .btn:focus-visible {{ transform: translateY(-1px); box-shadow: 0 10px 24px rgba(0,0,0,.35); border-color: rgba(255,255,255,.25); }}
    .muted {{ color: var(--muted); font-size: 13px; }}

    /* GRID */
    .grid {{ margin-top:18px; display:grid; grid-template-columns: repeat(3,1fr); gap:12px; }}
    .card {{
      background: var(--panel); border:1px solid var(--stroke); border-radius:16px; padding:16px;
      transition: transform .15s ease, border-color .15s ease, background .15s ease;
      position: relative;
    }}
    .card:hover {{ transform: translateY(-3px); border-color: rgba(255,255,255,.18); background: #171721; }}
    .emoji {{ font-size:26px; margin-bottom:6px; }}
    .card-title {{ margin:0 0 4px 0; font-size:16px; font-weight:800; color:var(--brand2); }}
    .card-desc {{ margin:0; color:var(--muted); font-size:13px; }}
    .chip {{
      position:absolute; top:12px; right:12px; font-size:11px; color:#eaeaf0;
      border:1px solid var(--stroke); border-radius:999px; padding:4px 8px; background:rgba(255,255,255,.04);
    }}

    /* MÉTRICAS */
    .metrics {{ margin-top:18px; display:grid; grid-template-columns: repeat(4,1fr); gap:12px; }}
    .metric {{
      text-align:center; border:1px solid var(--stroke); border-radius:16px; padding:16px;
      background: linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.015));
    }}
    .metric .num {{ font-size:28px; font-weight:900; letter-spacing:-0.6px; }}
    .metric .lbl {{ color:var(--muted); font-size:12px; }}

    /* SOBRE */
    .about {{ margin-top:22px; display:grid; grid-template-columns:1.2fr 1fr; gap:12px; }}
    .panel {{ background:var(--panel); border:1px solid var(--stroke); border-radius:16px; padding:16px; }}
    .panel h3 {{ margin:0 0 8px 0; }}
    .bio {{ color:var(--muted); font-size:14px; }}
    .tags {{ margin-top:8px; display:flex; flex-wrap:wrap; gap:8px; }}
    .tag {{ font-size:12px; color:#ececf2; padding:6px 10px; border-radius:999px; border:1px solid var(--stroke); background:rgba(255,255,255,.03); }}

    /* DIFERENCIAIS */
    .bullets {{ list-style:none; padding-left:0; margin:8px 0 0; }}
    .bullets li {{ margin:8px 0; color:var(--muted); font-size:14px; }}
    .bullets li::before {{ content:"✓"; color:var(--brand); font-weight:900; margin-right:8px; }}

    /* DEPOIMENTOS */
    .quotes {{ margin-top:12px; display:grid; grid-template-columns:1fr 1fr; gap:12px; }}
    .quote {{
      border:1px solid var(--stroke); border-radius:16px; padding:14px;
      background: linear-gradient(180deg, rgba(255,255,255,.04), rgba(255,255,255,.01));
      color:var(--muted); font-size:14px;
    }}
    .quote .who {{ color:#fff; margin-top:8px; font-weight:700; }}

    .footer {{ text-align:center; color:var(--muted); margin-top:16px; font-size:12.5px; }}

    @media (max-width:1100px) {{
      .grid {{ grid-template-columns:1fr 1fr; }}
      .metrics {{ grid-template-columns:1fr 1fr; }}
      .about {{ grid-template-columns:1fr; }}
      .quotes {{ grid-template-columns:1fr; }}
    }}
    @media (max-width:640px) {{
      .grid {{ grid-template-columns:1fr; }}
      .titulo {{ font-size:28px; }}
    }}

    /* acessibilidade: foco visível */
    :focus-visible {{ outline: 2px dashed var(--brand2); outline-offset: 2px; }}
    @media (prefers-reduced-motion: reduce) {{
      * {{ animation: none !important; transition: none !important; }}
    }}
  </style>
 </head>
 <body>
  <div class="wrap">
    <!-- HERO -->
    <section class="hero" role="banner" aria-label="Apresentação">
      <span class="badge">{saudacao}! 👋 Bem-vindo(a) ao</span>
      <h1 class="titulo"><span class="highlight">Lana Modas</span> — gestão de loja no seu ritmo</h1>
      <p class="sub">Sistema completo para registrar vendas, controlar despesas e enxergar seus números com clareza.</p>
      <div class="cta">{cta_html}</div>
    </section>

    <!-- CARDS PRINCIPAIS -->
    <section class="grid" aria-label="Módulos principais">
      <div class="card" tabindex="0" role="article" aria-label="Cadastro de Vendas">
        <span class="chip">Novo</span>
        <div class="emoji">📋</div>
        <h4 class="card-title">Cadastro de Vendas</h4>
        <p class="card-desc">Registro simples, desconto em %, exportação em PDF.</p>
      </div>
      <div class="card" tabindex="0" role="article" aria-label="Despesas">
        <div class="emoji">💸</div>
        <h4 class="card-title">Despesas</h4>
        <p class="card-desc">Categorias, histórico e integração com relatórios.</p>
      </div>
      <div class="card" tabindex="0" role="article" aria-label="Relatórios">
        <div class="emoji">📈</div>
        <h4 class="card-title">Relatórios</h4>
        <p class="card-desc">KPIs, gráficos interativos e PDF do período.</p>
      </div>
    </section>

    <!-- MÉTRICAS -->
    <section class="metrics" aria-label="Métricas de marketing">
      <div class="metric">
        <div class="num" data-target="{DEV.get('metric_clientes',0)}" data-suffix="" data-decimals="0">0</div>
        <div class="lbl">Clientes atendidos</div>
      </div>
      <div class="metric">
        <div class="num" data-target="{DEV.get('metric_projetos',0)}" data-suffix="" data-decimals="0">0</div>
        <div class="lbl">Projetos entregues</div>
      </div>
      <div class="metric">
        <div class="num" data-target="{DEV.get('metric_satisfacao',0)}" data-suffix="%" data-decimals="0">0</div>
        <div class="lbl">Satisfação</div>
      </div>
      <div class="metric">
        <div class="num" data-target="{DEV.get('metric_resposta_horas',0)}" data-suffix="h" data-decimals="0">0</div>
        <div class="lbl">Tempo de resposta</div>
      </div>
    </section>

    <!-- SOBRE / DIFERENCIAIS -->
    <section class="about" aria-label="Sobre e diferenciais">
      <div class="panel">
        <h3>Sobre <span class="highlight">{DEV.get('nome','')}</span></h3>
        <p class="bio">{DEV.get('headline','')} {DEV.get('sub','')}</p>
        <div class="tags" aria-label="Tecnologias">
          <span class="tag">Streamlit</span><span class="tag">Python</span><span class="tag">Plotly</span>
          <span class="tag">Relatórios PDF</span><span class="tag">Varejo de Moda</span><span class="tag">Automação</span>
        </div>
      </div>
      <div class="panel">
        <h3>Diferenciais</h3>
        <ul class="bullets">
          <li>Implantação rápida e suporte próximo ao cliente.</li>
          <li>Dashboards claros, focados no que importa.</li>
          <li>Exportação em PDF com layout profissional.</li>
          <li>Performance e simplicidade no dia a dia.</li>
        </ul>
      </div>
    </section>

    <!-- DEPOIMENTOS -->
    <section class="quotes" aria-label="Depoimentos">
      <div class="quote">“O sistema da Lana Modas organizou nossa rotina. Os relatórios em PDF ajudaram na tomada de decisão.”<div class="who">— Gestora de Loja</div></div>
      <div class="quote">“Atendimento excelente! O Pedro entendeu nossas necessidades e entregou rápido.”<div class="who">— Empresária do varejo</div></div>
    </section>

    <p class="footer">👨‍💻 Desenvolvido por {DEV.get('nome','')}</p>

    <script>
      // animação de contadores com sufixo e decimais
      const ease = (t)=>1 - Math.pow(1 - t, 3);
      const DURATION = 900;
      function animateNum(el){{
        const target = parseFloat(el.getAttribute('data-target')) || 0;
        const suffix = el.getAttribute('data-suffix') || "";
        const decimals = parseInt(el.getAttribute('data-decimals')||"0",10);
        const startVal = 0;
        const start = performance.now();
        function step(now){{
          const p = Math.min(1, (now - start)/DURATION);
          const val = startVal + (target - startVal)*ease(p);
          el.textContent = val.toFixed(decimals).replace('.', ',') + suffix;
          if (p < 1) requestAnimationFrame(step);
        }}
        requestAnimationFrame(step);
      }}
      const metrics = document.querySelectorAll('.metric .num');
      const io = new IntersectionObserver((entries)=>{{
        entries.forEach(e=>{{
          if(e.isIntersecting){{
            animateNum(e.target);
            io.unobserve(e.target);
          }}
        }});
      }},{{ threshold: .4 }});
      metrics.forEach(m=>io.observe(m));

      // acessibilidade: permitir Enter/Espaço ativar cartões (sem ação de clique ainda)
      document.querySelectorAll('.card[tabindex="0"]').forEach(card=>{{
        card.addEventListener('keydown', (ev)=>{{
          if(ev.key === 'Enter' || ev.key === ' '){{
            ev.preventDefault();
            card.classList.add('pulse');
            setTimeout(()=>card.classList.remove('pulse'), 250);
          }}
        }});
      }});
    </script>
  </div>
 </body>
 </html>
 """
 components.html(html_inicio, height=960, scrolling=True)

# ================== CADASTRO DE VENDAS ==================
elif escolha == "📋 Cadastro de Vendas":
    st.markdown("## 🛒 Cadastro de Vendas")
    st.markdown("Registre suas vendas com rapidez e acompanhe o histórico.")

    # Colunas fixas do CSV
    colunas_padrao = ["Data", "Produto", "Pagamento", "Valor", "Desconto(%)", "Valor Final"]

    # ---- Formulário de cadastro ----
    with st.form("form_venda", clear_on_submit=True):
        col1, col2, col3 = st.columns(3)
        with col1:
            data_v = st.date_input("📅 Data", value=date.today())
        with col2:
            produto = st.text_input("📦 Produto")
        with col3:
            pagamento = st.selectbox(
                "💳 Forma de Pagamento",
                ["Pix", "Cartão Débito", "Cartão Crédito", "Dinheiro", "Outro"]
            )

        col4, col5, col6 = st.columns(3)
        with col4:
            valor = st.number_input("💰 Valor (R$)", min_value=0.0, format="%.2f", step=0.01)
        with col5:
            desconto = st.number_input("🏷 Desconto (%)", min_value=0.0, max_value=100.0, format="%.2f", step=0.1)
        with col6:
            valor_final = valor - (valor * desconto / 100)
            st.metric("💵 Valor Final", f"R$ {valor_final:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))

        # botão do formulário → define a variável 'enviar'
        enviar = st.form_submit_button("💾 Salvar Venda")

    # toda a lógica de salvar vem DEPOIS do with st.form
    if enviar:
        try:
            # nova linha
            nova = pd.DataFrame(
                [[pd.to_datetime(data_v).strftime("%Y-%m-%d"), produto, pagamento, valor, desconto, valor_final]],
                columns=colunas_padrao
            )

            # lê atual, garante colunas/ordem
            df_vendas = safe_read_csv(ARQ_REGISTROS)
            if df_vendas.empty:
                df_vendas = pd.DataFrame(columns=colunas_padrao)
            for c in colunas_padrao:
                if c not in df_vendas.columns:
                    df_vendas[c] = None
            df_vendas = df_vendas[colunas_padrao]

            # apende e grava
            df_vendas = pd.concat([df_vendas, nova], ignore_index=True)
            safe_write_csv(df_vendas, ARQ_REGISTROS)

            st.success("✅ Venda registrada com sucesso!")
            st.toast(f"Salvo em: {ARQ_REGISTROS}", icon="💾")
        except Exception as e:
            st.error(f"❌ Erro ao salvar vendas: {type(e).__name__}: {e}")

    # ---- Histórico de vendas (sempre que existir arquivo) ----
    if os.path.exists(ARQ_REGISTROS):
        df_vendas = safe_read_csv(ARQ_REGISTROS)
        df_vendas["Data"] = pd.to_datetime(df_vendas["Data"], errors="coerce")

        # Filtro de período
        st.markdown("### 📅 Filtrar Vendas por Data")
        colf1, colf2 = st.columns(2)
        with colf1:
            data_inicio = st.date_input("Data Inicial", value=date.today() - timedelta(days=7))
        with colf2:
            data_fim = st.date_input("Data Final", value=date.today())

        # Aplicar filtro
        df_filtrado = df_vendas[
            df_vendas["Data"].between(pd.to_datetime(data_inicio), pd.to_datetime(data_fim))
        ]

        st.markdown(f"**Vendas de {data_inicio.strftime('%d/%m/%Y')} a {data_fim.strftime('%d/%m/%Y')}**")
        st.dataframe(
            df_filtrado.style.format({
                "Valor": "R$ {:.2f}",
                "Desconto(%)": "{:.2f}%",
                "Valor Final": "R$ {:.2f}"
            }),
            use_container_width=True
        )
    else:
        st.info("Nenhuma venda registrada ainda.")

# ================== DESPESAS ==================
elif escolha == "💸 Despesas":
    st.markdown("""
        <h1 style='color:#FF006F;text-align:center;font-weight:bold;'>💸 Controle de Despesas</h1>
        <p style='text-align:center;color:#ccc;'>Monitore seus gastos e mantenha o lucro no caminho certo</p>
    """, unsafe_allow_html=True)

    # Carrega / garante colunas
    df_despesas = carregar_csv(ARQ_DESPESAS, ["Data", "Categoria", "Descricao", "Valor"])
    df_despesas["Data"] = pd.to_datetime(df_despesas["Data"], errors="coerce")
    df_despesas["Valor"] = pd.to_numeric(df_despesas["Valor"], errors="coerce").fillna(0)
    df_despesas = df_despesas.dropna(subset=["Data"])  # remove linhas sem data

    # ---------- Formulário ----------
    with st.form("form_desp"):
        c1, c2 = st.columns([1, 1])
        with c1:
            data_d = st.date_input("📅 Data da despesa", value=date.today())
        with c2:
            valor_d = st.number_input("💰 Valor (R$)", min_value=0.0, format="%.2f")

        c3, c4 = st.columns([1, 2])
        with c3:
            categoria = st.selectbox("📂 Categoria", ["Roupas", "Salário", "Aluguel", "Outros"])
        with c4:
            descricao = st.text_input("📝 Descrição")

        enviar = st.form_submit_button("💾 Salvar Despesa")

        if enviar:
            if not descricao.strip():
                st.warning("⚠️ A descrição não pode estar vazia.")
            else:
                # nova linha
                nova = pd.DataFrame([{
                    "Data": pd.to_datetime(data_d),
                    "Categoria": categoria,
                    "Descricao": descricao.strip(),
                    "Valor": float(valor_d)
                }])

                # atualiza df (tipos garantidos)
                df_despesas = pd.concat([df_despesas, nova], ignore_index=True)
                df_despesas["Data"] = pd.to_datetime(df_despesas["Data"], errors="coerce")
                df_despesas["Valor"] = pd.to_numeric(df_despesas["Valor"], errors="coerce").fillna(0)

                # salva CSV
                df_despesas.to_csv(ARQ_DESPESAS, index=False, encoding="utf-8")
                st.success("✅ Despesa salva com sucesso!")
                st.rerun()

    # ---------- Exibição ----------
    if not df_despesas.empty:
        df_exibir = df_despesas.sort_values("Data", ascending=False).copy()
        df_exibir["Data"] = pd.to_datetime(df_exibir["Data"], errors="coerce").dt.strftime("%d/%m/%Y")
        st.dataframe(df_exibir, use_container_width=True)
    else:
        st.info("Nenhuma despesa cadastrada ainda.")


    # ================== RELATÓRIOS ==================
# ----- Cabeçalho estilizado -----
elif escolha == "📈 Relatórios":
    st.markdown("""
        <style>
          .lm-badge{
            display:inline-block; padding:6px 12px; border:1px solid rgba(255,255,255,.12);
            border-radius:999px; color:#b8b8c2; font-size:12px;
            background:rgba(255,255,255,.03);
          }
          .lm-chip{
            display:inline-block; padding:6px 10px; border-radius:999px;
            border:1px solid rgba(255,255,255,.08); font-size:12px; color:#d9d9e3;
            background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02));
            margin: 0 6px 6px 0;
          }
        </style>
        <div style="text-align:center; margin: 0 0 26px 0;">
          <span class="lm-badge">📈 Relatórios & KPIs</span>
          <h1 style="
              margin:12px 0 6px 0;
              font-size:2.6em;
              font-weight:800;
              letter-spacing:-.5px;
              line-height:1.1;
              background: linear-gradient(90deg, #6a3df5, #FF006F);
              -webkit-background-clip: text;
              -webkit-text-fill-color: transparent;">
              Dashboard Financeiro
          </h1>
          <p style="margin:0;color:#cccccc;font-size:1.05em;">
              Análises interativas com Plotly • período flexível • linha do tempo diária • PDF do período.
          </p>
          <div style="margin-top:12px;">
            <span class="lm-chip">Vendas</span>
            <span class="lm-chip">Despesas</span>
            <span class="lm-chip">Lucro</span>
            <span class="lm-chip">Ticket médio</span>
            <span class="lm-chip">Formas de pagamento</span>
          </div>
        </div>
    """, unsafe_allow_html=True)
    st.divider()

    # ---------- Utilitários ----------
    def ler_csv_flex(caminho):
        if not os.path.exists(caminho):
            return pd.DataFrame()
        for sep in [",", ";", "\t"]:
            try:
                return pd.read_csv(caminho, sep=sep)
            except Exception:
                continue
        return pd.DataFrame()

    def padroniza_vendas(df_raw):
        if df_raw.empty:
            return pd.DataFrame(columns=["Data", "Produto", "Pagamento", "Valor", "DescontoPerc", "ValorFinal"])
        df = df_raw.copy()
        df = df.rename(columns={"Desconto(%)": "DescontoPerc", "Valor Final": "ValorFinal"})
        for col in ["Data", "Produto", "Pagamento", "Valor", "DescontoPerc", "ValorFinal"]:
            if col not in df.columns:
                df[col] = None
        df["Data"] = pd.to_datetime(df["Data"], errors="coerce")
        for c in ["Valor", "DescontoPerc", "ValorFinal"]:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df["ValorFinal"] = df["ValorFinal"].fillna(df["Valor"])
        df = df.dropna(subset=["Data"])
        return df

    def padroniza_despesas(df_raw):
        if df_raw.empty:
            return pd.DataFrame(columns=["Data", "Categoria", "Descricao", "Valor"])
        df = df_raw.copy()
        for col in ["Data", "Categoria", "Descricao", "Valor"]:
            if col not in df.columns:
                df[col] = None
        df["Data"] = pd.to_datetime(df["Data"], errors="coerce")
        df["Valor"] = pd.to_numeric(df["Valor"], errors="coerce")
        df = df.dropna(subset=["Data"])
        return df

    # ---------- Carregar bases (EVITA NameError) ----------
    ARQ_REGISTROS = globals().get("ARQ_REGISTROS", "vendas.csv")
    ARQ_DESPESAS  = globals().get("ARQ_DESPESAS",  "despesas.csv")
    df_vendas   = padroniza_vendas(ler_csv_flex(ARQ_REGISTROS))
    df_despesas = padroniza_despesas(ler_csv_flex(ARQ_DESPESAS))

    # ---------- Período OU dia único ----------
    opcoes_periodo = [
        "Dia específico", "Hoje", "7 dias",
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ]
    col1, col2, col3 = st.columns([2, 1, 2])
    with col1:
        opcao_periodo = st.selectbox("📅 Período de Análise:", opcoes_periodo, index=0)
    with col2:
        ano_escolhido = st.number_input("Ano", min_value=2000, max_value=2100, value=date.today().year)
    with col3:
        data_especifica = st.date_input("Escolha o dia", value=date.today()) if opcao_periodo == "Dia específico" else None

    hoje = date.today()
    if opcao_periodo == "Dia específico":
        data_inicio = data_especifica
        data_fim = data_especifica
    elif opcao_periodo == "Hoje":
        data_inicio = hoje
        data_fim = hoje
    elif opcao_periodo == "7 dias":
        data_inicio = hoje - timedelta(days=6)
        data_fim = hoje
    else:
        meses_map = {
            "Janeiro": 1, "Fevereiro": 2, "Março": 3, "Abril": 4, "Maio": 5, "Junho": 6,
            "Julho": 7, "Agosto": 8, "Setembro": 9, "Outubro": 10, "Novembro": 11, "Dezembro": 12
        }
        mes_num = meses_map[opcao_periodo]
        data_inicio = date(ano_escolhido, mes_num, 1)
        data_fim = date(ano_escolhido, mes_num, calendar.monthrange(ano_escolhido, mes_num)[1])

    st.caption(f"Período selecionado: {pd.to_datetime(data_inicio).strftime('%d/%m/%Y')} até {pd.to_datetime(data_fim).strftime('%d/%m/%Y')}")

    # ---------- Filtrar período ----------
    vendas_f = df_vendas[df_vendas["Data"].between(pd.to_datetime(data_inicio), pd.to_datetime(data_fim))].copy()
    despesas_f = df_despesas[df_despesas["Data"].between(pd.to_datetime(data_inicio), pd.to_datetime(data_fim))].copy()

    # ---------- Série diária contínua ----------
    intervalo = pd.date_range(pd.to_datetime(data_inicio), pd.to_datetime(data_fim), freq="D")
    v_dia = (vendas_f.set_index("Data").resample("D")["ValorFinal"].sum().reindex(intervalo, fill_value=0))
    d_dia = (despesas_f.set_index("Data").resample("D")["Valor"].sum().reindex(intervalo, fill_value=0))
    df_diario = pd.DataFrame({"Data": intervalo, "Vendas": v_dia.values.astype(float), "Despesas": d_dia.values.astype(float)})
    df_diario["Lucro"] = df_diario["Vendas"] - df_diario["Despesas"]

    # ---------- KPIs ----------
    total_bruto = float(vendas_f["Valor"].fillna(0).sum())
    total_liq   = float(vendas_f["ValorFinal"].fillna(0).sum())
    descontos   = float((vendas_f["Valor"].fillna(0) - vendas_f["ValorFinal"].fillna(0)).sum())
    total_desp  = float(despesas_f["Valor"].fillna(0).sum())
    lucro       = total_liq - total_desp

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("💰 Vendas Brutas", f"R$ {total_bruto:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
    k2.metric("🏷 Descontos",     f"R$ {descontos:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
    k3.metric("📊 Lucro",         f"R$ {lucro:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
    k4.metric("💸 Despesas",      f"R$ {total_desp:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))

    # ---------- helpers ----------
    def _fmt_brl(v):
        return f"R$ {float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    def _plotly_base(fig, titulo=None):
        if titulo:
            fig.update_layout(title=dict(text=titulo, x=0.01, xanchor="left"))
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=10, r=160, t=50, b=40),
            hoverlabel=dict(bgcolor="rgba(20,20,20,0.9)", font_size=12),
            legend=dict(orientation="v", yanchor="middle", y=0.5, xanchor="left", x=1.02, traceorder="normal", bgcolor="rgba(0,0,0,0)"),
            font=dict(size=13),
        )
        fig.update_xaxes(showgrid=False, tickformat="%d/%m", automargin=True)
        fig.update_yaxes(title=None, tickprefix="R$ ", separatethousands=True, automargin=True)
        return fig

    # ---------- Gráfico linha ----------
    df_diario_plot = df_diario.copy()
    df_diario_plot["Vendas_MA7"] = df_diario_plot["Vendas"].rolling(7, min_periods=1).mean()
    fig_line = px.line(df_diario_plot, x="Data", y=["Vendas", "Despesas", "Lucro", "Vendas_MA7"], markers=True)
    fig_line.for_each_trace(lambda tr: tr.update(line=dict(shape="spline")) if tr.name == "Vendas_MA7" else ())
    fig_line.for_each_trace(lambda t: t.update(hovertemplate="%{x|%d/%m/%Y}<br>%{y:.2f}"))
    _plotly_base(fig_line, "📅 Evolução Diária (com Média Móvel 7d)")
    st.plotly_chart(fig_line, use_container_width=True)

    # ---------- Barras comparativas ----------
    fig_bar = px.bar(df_diario_plot, x="Data", y=["Vendas", "Despesas", "Lucro"], barmode="group")
    fig_bar.for_each_trace(lambda t: t.update(hovertemplate="%{x|%d/%m/%Y}<br>%{y:.2f}"))
    _plotly_base(fig_bar, "📊 Comparativo Diário (Vendas × Despesas × Lucro)")
    st.plotly_chart(fig_bar, use_container_width=True)

    # ---------- Formas de pagamento ----------
    if not vendas_f.empty and "Pagamento" in vendas_f.columns:
        dist_pag = (vendas_f.groupby("Pagamento", dropna=False)["ValorFinal"].sum()
                    .reset_index().sort_values("ValorFinal", ascending=False))
        if not dist_pag.empty:
            fig_pag = px.pie(dist_pag, names="Pagamento", values="ValorFinal", hole=0.45)
            fig_pag.update_traces(textinfo="percent+label", hovertemplate="%{label}<br>%{value:.2f}")
            _plotly_base(fig_pag, "💳 Distribuição por Forma de Pagamento")
            st.plotly_chart(fig_pag, use_container_width=True)

    # ---------- Top 10 Produtos ----------
    if not vendas_f.empty and "Produto" in vendas_f.columns:
        top_prod = (vendas_f.groupby("Produto", dropna=False)["ValorFinal"].sum()
                    .reset_index().sort_values("ValorFinal", ascending=False).head(10))
        if not top_prod.empty:
            fig_top = px.bar(top_prod, x="Produto", y="ValorFinal")
            fig_top.update_xaxes(tickangle=-20)
            fig_top.update_traces(hovertemplate="%{x}<br>%{y:.2f}")
            _plotly_base(fig_top, "🏆 Top 10 Produtos por Receita (Valor Final)")
            st.plotly_chart(fig_top, use_container_width=True)

   # =================== EXPORTAÇÃO SOMENTE PDF (APrimorada) ===================
st.divider()
st.caption("📄 Exportação")

from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    LongTable, Table, TableStyle, PageBreak, Image as RLImage
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as _canvas

def _fmt_brl_safe(v):
    try:
        return _fmt_brl(v)  # usa sua função se existir
    except Exception:
        v = 0 if pd.isna(v) else float(v)
        return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def _draw_header_footer(c: _canvas.Canvas, doc):
    brand = colors.HexColor("#FF006F")
    w, h = A4
    c.saveState()
    # Header bar
    c.setFillColor(brand); c.rect(0, h-18*mm, w, 18*mm, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 13)
    c.drawString(12*mm, h-11*mm, "Relatório Financeiro - Lana Modas")
    c.setFont("Helvetica", 9)
    c.drawRightString(w-12*mm, h-11*mm,
                      f"Período: {pd.to_datetime(data_inicio).strftime('%d/%m/%Y')} a {pd.to_datetime(data_fim).strftime('%d/%m/%Y')}")
    # Footer
    c.setFillColor(colors.grey)
    c.setFont("Helvetica", 8)
    c.drawString(12*mm, 10*mm, "Gerado por Lana Modas")
    c.drawRightString(w-12*mm, 10*mm, f"Página {doc.page}")
    c.restoreState()

def _fig_to_story(fig, width_mm=178, ratio=16/9):
    # Requer: pip install -U kaleido
    try:
        import plotly.io as pio
        png = pio.to_image(fig, format="png", width=1600, height=int(1600/ (width_mm/25.4) / ratio), scale=2, engine="kaleido")
        bio = BytesIO(png)
        w = min(width_mm*mm, A4[0]-24*mm)
        h = w / ratio
        return RLImage(bio, width=w, height=h)
    except Exception as e:
        return Paragraph(
            "Obs.: Para incluir gráficos no PDF, instale o pacote <b>kaleido</b> (pip install -U kaleido).",
            ParagraphStyle("warn", parent=getSampleStyleSheet()["BodyText"], textColor=colors.red, fontSize=9)
        )

if st.button("Gerar Relatório PDF"):
    buffer = BytesIO()

    # ---- Styles
    styles = getSampleStyleSheet()
    h2 = ParagraphStyle(
        "H2",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        textColor=colors.HexColor("#FF006F"),
        spaceBefore=8, spaceAfter=6
    )
    body = ParagraphStyle("Body", parent=styles["BodyText"], fontSize=9.5, leading=12)

    # ---- Doc + template (header/footer)
    doc = BaseDocTemplate(
        buffer, pagesize=A4,
        leftMargin=12*mm, rightMargin=12*mm, topMargin=28*mm, bottomMargin=16*mm,
        title="Relatório Financeiro - Lana Modas", author="Lana Modas",
        subject="Vendas, Despesas e Lucro"
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='normal')
    doc.addPageTemplates([
        PageTemplate(id='p1', frames=frame, onPage=_draw_header_footer, onPageEnd=None)
    ])

    story = []

    # ---- KPIs
    total_bruto = float(total_bruto) if 'total_bruto' in locals() else 0.0
    descontos   = float(descontos)   if 'descontos'   in locals() else 0.0
    total_desp  = float(total_desp)  if 'total_desp'  in locals() else 0.0
    lucro       = float(lucro)       if 'lucro'       in locals() else (total_bruto - descontos - total_desp)

    kpi_data = [
        ["Vendas Brutas",   _fmt_brl_safe(total_bruto)],
        ["Descontos",       _fmt_brl_safe(descontos)],
        ["Despesas",        _fmt_brl_safe(total_desp)],
        ["Lucro (Líquido)", _fmt_brl_safe(lucro)],
    ]
    kpi = Table(kpi_data, colWidths=[70*mm, 40*mm], hAlign="LEFT")
    kpi.setStyle(TableStyle([
        ("FONT",        (0,0), (-1,-1), "Helvetica", 10),
        ("ALIGN",       (1,0), (1,-1),  "RIGHT"),
        ("GRID",        (0,0), (-1,-1), 0.25, colors.Color(0.75,0.75,0.75)),
        ("BOX",         (0,0), (-1,-1), 0.25, colors.Color(0.75,0.75,0.75)),
        ("BACKGROUND",  (0,0), (-1,0),  colors.whitesmoke),
        ("TEXTCOLOR",   (0,3), (-1,3),  colors.HexColor("#0b0b0e")),
        ("BACKGROUND",  (0,3), (-1,3),  colors.Color(1,0,0.435, 0.10)),
    ]))
    story += [Spacer(1, 6), kpi, Spacer(1, 10)]

    # ---- Tabela diária (com cabeçalho repetido, listras e totalização)
    df_tbl = df_diario.copy() if 'df_diario' in locals() else pd.DataFrame(columns=["Data","Vendas","Despesas","Lucro"])
    if not df_tbl.empty:
        df_tbl = df_tbl.copy()
        df_tbl["Data"] = pd.to_datetime(df_tbl["Data"]).dt.strftime("%d/%m/%Y")
        df_tbl["Vendas_fmt"]   = df_tbl["Vendas"].apply(_fmt_brl_safe)
        df_tbl["Despesas_fmt"] = df_tbl["Despesas"].apply(_fmt_brl_safe)
        df_tbl["Lucro_fmt"]    = df_tbl["Lucro"].apply(_fmt_brl_safe)

        header = [["Data", "Vendas", "Despesas", "Lucro"]]
        rows = df_tbl[["Data","Vendas_fmt","Despesas_fmt","Lucro_fmt"]].values.tolist()

        # Totais
        tot_row = [
            "Total",
            _fmt_brl_safe(df_tbl["Vendas"].sum()),
            _fmt_brl_safe(df_tbl["Despesas"].sum()),
            _fmt_brl_safe(df_tbl["Lucro"].sum()),
        ]
        data_table = header + rows + [tot_row]

        lt = LongTable(data_table, colWidths=[30*mm, 42*mm, 42*mm, 42*mm], repeatRows=1)
        lt.setStyle(TableStyle([
            ("FONT",          (0,0), (-1,-1), "Helvetica", 9),
            ("ALIGN",         (1,1), (-1,-2), "RIGHT"),
            ("ALIGN",         (1,-1), (-1,-1), "RIGHT"),
            ("BACKGROUND",    (0,0), (-1,0),  colors.Color(.2,.2,.2)),
            ("TEXTCOLOR",     (0,0), (-1,0),  colors.whitesmoke),
            ("ROWBACKGROUNDS",(0,1), (-1,-2), [colors.whitesmoke, colors.Color(0.97,0.97,0.97)]),
            ("GRID",          (0,0), (-1,-1), 0.25, colors.Color(0.75,0.75,0.75)),
            ("LINEABOVE",     (0,-1), (-1,-1), 0.5, colors.HexColor("#FF006F")),
            ("FONT",          (0,-1), (-1,-1), "Helvetica-Bold", 9),
        ]))
        story += [Paragraph("Detalhamento diário", h2), lt, Spacer(1, 10)]
    else:
        story += [Paragraph("Não há dados diários no período selecionado.", body), Spacer(1, 6)]

    # ---- Gráficos (em páginas seguintes):
    # Use qualquer combinação das figuras que você já criou: fig_line, fig_bar, fig_pag, fig_top
    figs = []
    if 'fig_line' in locals(): figs.append(("Evolução diária", fig_line))
    if 'fig_bar'  in locals(): figs.append(("Comparativo diário (Vendas x Despesas x Lucro)", fig_bar))
    if 'fig_pag'  in locals(): figs.append(("Distribuição de pagamentos", fig_pag))
    if 'fig_top'  in locals(): figs.append(("Top 10 produtos", fig_top))

    if figs:
        story.append(PageBreak())
        for i, (titulo, fig) in enumerate(figs):
            story += [Paragraph(titulo, h2), _fig_to_story(fig), Spacer(1, 8)]
            if i < len(figs)-1:
                story.append(Spacer(1, 4))

    # ---- Build & download
    try:
        doc.build(story)
        st.download_button(
            "📄 Baixar PDF do Relatório",
            buffer.getvalue(),
            file_name=f"relatorio_lana_{pd.Timestamp.now().strftime('%Y%m%d_%H%M')}.pdf",
            mime="application/pdf"
        )
    except Exception as e:
        st.error(f"Erro ao gerar PDF: {e}\nTente instalar/atualizar: pip install reportlab kaleido plotly -U")
